<?php
$connessione=mysqli_connect('localhost','root','covidserver','positivi') or die ("Connessione non avvenuta");
$sql="SELECT code FROM codici_non_usati where code='".$_POST["code"]."'";

$query=mysqli_query($connessione,$sql);
$result=mysqli_fetch_assoc($query);

if(!empty($result)){
    $query="INSERT INTO codici_usati(code) VALUES('".$result["code"]."')";
    mysqli_query($connessione,$query);
    $query="DELETE FROM codici_non_usati WHERE code='".$result["code"]."'";
    mysqli_query($connessione,$query);
    echo "<script>window.alert(\"Il codice è stato utilizzato con successo \");</script>";
}
else{
    echo "<script>window.alert(\"Il codice non è valido \");</script>";
}
mysqli_close($connessione);
echo "<script>window.location.replace(\"insertcode.php\");</script>";
?>