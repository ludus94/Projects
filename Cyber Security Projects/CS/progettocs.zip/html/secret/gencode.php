<?php
include ('fpdf/fpdf.php');
function gencode(){
    if($_POST["risposta"]=='si'){
        $date=new DateTime();
        $date->getTimestamp();
        $lenghtkey=128;
        $rand=random_bytes($lenghtkey);
        $code=hash('sha512',$rand.hash('sha512',$date_hash));
        print_pdf($code);
    }
    else{
        print_pdf_neg();
    }
    
}

function print_pdf($code){
    $connessione=mysqli_connect('localhost','root','covidserver','positivi') or die ("Connessione non avvenuta");
    $query="INSERT INTO codici_non_usati(code) VALUES('$code')";
    mysqli_query($connessione,$query);
    print(mysqli_error($connessione));
    
    $pdf=new FPDF('P',"mm","A4");
    $pdf->AddPage();
    $pdf->SetFont('Arial','B',16);
    $pdf->Image("fpdf/testata.png",null,null,195,50);
    $pdf->Ln(10);
    $pdf->SetX(75);
    $pdf->Cell(65,10,"Risultato analisi: Covid Positivo");
    $pdf->Ln();
    $pdf->SetX(0);
    $pdf->SetFont('Arial','I',8);
    $pdf->Cell(22,10,"Code:".$code);
    $pdf->Output('D',"Positivo".$code.".pdf");
    mysqli_close($connessione);
}
function print_pdf_neg(){
    $pdf=new FPDF('P',"mm","A4");
    $pdf->AddPage();
    $pdf->SetFont('Arial','B',16);
    $pdf->Image("fpdf/testata.png",null,null,195,50);
    $pdf->Ln(10);
    $pdf->SetX(75);
    $pdf->Cell(65,10,"Risultato analisi: Covid Negativo");
    $pdf->Ln();
    $pdf->Output('D',"Negativo.pdf");
}
    gencode();
    echo "<script>window.location.replace(\"esitoesame.php\");</script>"
?>
