<?php
require('libreriapagine.php');
function gencert(){
    $dn = array(	"c"		=> "IT",
		"st"	=> str_replace(" ","",$_POST["stateOrProvinceName"]),
		"l"		=> str_replace(" ","",$_POST["localityName"]),
		"o"	=> str_replace(" ","",$_POST["organizationName"]),
		"ou"=>str_replace(" ","",$_POST["organizationName"]),
		"cn"		=> str_replace(" ","",$_POST["commonName"]),
		
);
	$request_cert='openssl req -new -newkey rsa:2048 -out client_certificate/myreq_client_'.$dn["o"].'_'.$dn["cn"].'.pem -keyout  client_certificate/mykey_client_'.$dn["o"].'_'.$dn["cn"].'.pem -subj "/C='.$dn["c"].'/ST='.$dn["st"].'/L='.$dn["l"].'/O='.$dn["o"].'/OU='.$dn["ou"].'/CN='.$dn["cn"].'" -nodes -days 365 -config certificate/opensslclient.cnf';
	shell_exec($request_cert);
	$ca_request='openssl ca -batch -in client_certificate/myreq_client_'.$dn["o"].'_'.$dn["cn"].'.pem -out client_certificate/mycert_client_'.$dn["o"].'_'.$dn["cn"].'.pem -config certificate/opensslclient.cnf';
	shell_exec($ca_request);
	$export_cert='openssl pkcs12 -export -chain -CAfile demoCA/cacert.pem -inkey client_certificate/mykey_client_'.$dn["o"].'_'.$dn["cn"].'.pem -name '.$dn["cn"].' -in client_certificate/mycert_client_'.$dn["o"].'_'.$dn["cn"].'.pem -out  client_certificate/mycert_client_'.$dn["o"].'_'.$dn["cn"].'.p12 -password pass:';
	shell_exec($export_cert);
	if(file_exists('client_certificate/myreq_client_'.$dn["o"].'_'.$dn["cn"].'.pem') & file_exists('client_certificate/mykey_client_'.$dn["o"].'_'.$dn["cn"].'.pem') & file_exists('client_certificate/mycert_client_'.$dn["o"].'_'.$dn["cn"].'.pem') & file_exists('client_certificate/mycert_client_'.$dn["o"].'_'.$dn["cn"].'.p12')){
		echo '<a class="iconaDownloadNeraNEW" href="client_certificate/myreq_client_'.$dn["o"].'_'.$dn["cn"].'.pem" download="client_certificate/myreq_client_'.$dn["o"].'_'.$dn["cn"].'.pem">Download Richiesta Certificato</a></br>';
		echo '<a class="iconaDownloadNeraNEW" href="client_certificate/mykey_client_'.$dn["o"].'_'.$dn["cn"].'.pem" download="client_certificate/mykey_client_'.$dn["o"].'_'.$dn["cn"].'.pem">Download Chiave Certificato</a></br>';
		echo '<a class="iconaDownloadNeraNEW" href="client_certificate/mycert_client_'.$dn["o"].'_'.$dn["cn"].'.pem" download="client_certificate/mycert_client_'.$dn["o"].'_'.$dn["cn"].'.pem">Download Certificato fomrato pem</a></br>';
		echo '<a class="iconaDownloadNeraNEW" href="client_certificate/mycert_client_'.$dn["o"].'_'.$dn["cn"].'.p12" download="client_certificate/mycert_client_'.$dn["o"].'_'.$dn["cn"].'.p12">Download Certificato per l\'accesso</a></br>';
	}
}


    partesuperiore('Generazione Certificati client');
    body('Generazione dei certificati client');
    navbar();
    corpo();
	if(!empty($_POST))
		 gencert();
    endcorpo();

?>