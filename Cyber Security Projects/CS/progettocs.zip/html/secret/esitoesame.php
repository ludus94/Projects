<?php
include('libreriapagine.php');
 partesuperiore('Esito esame');
    body('Comunicazione esito esame');
    navbar();
    corpo();
echo <<<_END
            <h3 style="font-size:30px;margin:0;" class="blu-italia-base-color">
					Esito esame
				</h3>
        <form autocomplete="off" method="post" name="generaform" action="../secret/gencode.php">
            <p>Il paziente &egrave risultato positivo?</p>
            <input type="radio" id="si" name="risposta" value="si">
            <label for="si">Si</label><br>
            <input type="radio" id="no" name="risposta" value="no">
            <label for="no">No</label><br>
            <input type="submit" class="btn-s btn-default-s btn-sm">
        </form>
_END;
endcorpo();
?>