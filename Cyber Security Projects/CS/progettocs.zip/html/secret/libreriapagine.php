<?php
    function partesuperiore($title){
        echo <<<_END
        <!DOCTYPE html SYSTEM "about:legacy-compat">
        <html xmlns="http://www.w3.org/1999/xhtml" lang="IT" xml:lang="IT">
        <head>
            <title>
                $title
            </title>
            <meta charset="utf-8"/>
            <meta content="IE=edge" http-equiv="X-UA-Compatible"/>
            <meta content="Sito tematico del Ministero della Salute dedicato al Nuovo coronavirus" name="DC.description"/>
            <meta content="Sito tematico del Ministero della Salute dedicato al Nuovo coronavirus" name="description"/>
            <meta content="Covid Positivi" name="author"/>
            <meta content="width=device-width, initial-scale=1" name="viewport"/>
            <link rel="shortcut icon" href="../favicon.ico"/>
            <link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Titillium+Web:400,200,200italic,300italic,300,400italic,600,600italic,700,700italic,900"/>
            <link href="../styles/combined-1e845f327b.css" rel="stylesheet"/>
            <link href="../styles/brands.css" rel="stylesheet"/>
            <link href="../styles/fontawesome.css" rel="stylesheet"/>
        </head>
_END;
    }
    function body($description){
        echo <<<_END
        <body>
            <div class="nav-banner">
            <div class="container">
            <div class="row">
            <div class="col-md-1 col-md-offset-3">
            <img title="Logo" alt="Logo" src="../images/loghi/stellone.png" class="navbar__logo"/>
            </div>
            <div class="col-md-6">
            <p class="h4">
            <a onclick="window.open(this.href);return false" title="Collegamento al sito www.covidpositivi.gov.it. Apre una nuova pagina." href="https://www.covidpositivi.gov.it/" style="color:#fff;text-decoration:none;">Ministero della Salute</a>
            </p>
        </div>
        </div>
        </div>
        </div>
        <div id="page_top" class="container">
        <header id="navbar" class="navbar navbar-default navbar-fixed-top hidden-print">
        <div class="navbar-header container">
        <div class="row">
            <a aria-controls="navbar" data-target="#navbar" data-toggle="offcanvas" title="navigazione" aria-label="apri e chiudi menu" class="navbar-toggle" href="#" id="nav-toggle">
            <span style="font-size:0px;">.</span>
        </a>
        <div style="width:100%;" class="col-xs-8 col-xs-offset-0 col-sm-5 col-sm-offset-0 col-md-5 col-md-offset-0 navbar__title_container normalizza-margine-titolo">
        <h1>
            <a tabindex="-1" href="https://covidpositivi.gov.it" accesskey="1">
        <span>$description</span>
        </a>
        </h1>
        </div>

</header>
_END;
    }
    function navbar(){
        echo <<<_END
        <div class="row row-offcanvas row-offcanvas-left">
        <div id="sidebar" class="col-md-4 sidebar-offcanvas">
        <nav data-offset-bottom="250" data-offset-top="0" data-spy="_affix" tabindex="0" id="menu" class="hidden-print">
        <h3 class="sr-only">Menu di navigazione del sito</h3>
        <ul class="nav navgoco">
        <li>
            <a href="../secret/index.php">Home</a>
        </li>
        <li>
            <a href="../secret/esitoesame.php">Genera esito esame</a>
        </li>
        <li>
            <a href="../secret/generacertificato.php">Genera certificato di accesso</a>
        </li>
        <li>
             <a href="../index.html">Logout</a>
        </li>
        </ul>
        </nav>
        </div>
        </div>
        </div>
_END;
    }
    function corpo(){
        echo<<<_END
        <div style="background-color:#f5f5f5;padding-left: 10px;" class="col-lg-12 col-md-12">
        <div style="background-color:#c9d6d6d6e8fd;padding-top:8em;padding-bottom:1em;padding-left: 0;" id="datiItalia">
        <div style="text-align:left;padding-left: 0;" class="col-lg-12 col-md-12 col-sm-12">
_END;
    }
    function endcorpo(){
        echo <<<_END
</div>
</div>
</div>
</div>



<footer tabindex="0" class="hidden-print" id="footer">
<div class="container">
<div class="row">
<div class="col-md-2">
<img title="Logo" alt="Logo" src="../images/loghi/stellone.png" class="footer__logo"/>
</div>
<div class="col-md-6">
<p style="font-weight:normal;font-size:27px;" class="footer__title h3">
							&copy; 2020 - Testata di propriet&agrave; del Ministero della Salute<br/>
</p>
</div>
<div class="col-md-4">
<div style="margin-top:0.5em;text-align:right;">
<span style="color:#fff;" id="social-footer">Seguici su:
							<a style="padding-left:5px;text-decoration:none;" onclick="window.open(this.href);return false" title="Collegamento alla pagina Facebook del Ministero della Salute. Apre una nuova pagina." href="https://www.facebook.com/MinisteroSalute">
<span class="fab fa-facebook">
<span style="color:transparent;font-size:0px;">.</span>
</span>
</a>
<a style="padding-left:5px;text-decoration:none;" onclick="window.open(this.href);return false" title="Collegamento alla pagina Twitter del Ministero della Salute. Apre una nuova pagina." href="https://twitter.com/ministerosalute">
<span class="fab fa-twitter">
<span style="color:transparent;font-size:0px;">.</span>
</span>
</a>
<a style="padding-left:5px;text-decoration:none;" onclick="window.open(this.href);return false" title="Collegamento al canale Youtube del Ministero della Salute. Apre una nuova pagina." href="https://www.youtube.com/user/MinisteroSalute">
<span class="fab fa-youtube">
<span style="color:transparent;font-size:0px;">.</span>
</span>
</a>
<a style="padding-left:5px;text-decoration:none;" onclick="window.open(this.href);return false" title="Collegamento alla pagina Instagram del Ministero della Salute. Apre una nuova pagina." href="https://www.instagram.com/ministerosalute">
<span class="fab fa-instagram">
<span style="color:transparent;font-size:0px;">.</span>
</span>
</a>
<a style="padding-left:5px;text-decoration:none;" onclick="window.open(this.href);return false" title="Collegamento al canale Telegram del Ministero della Salute. Apre una nuova pagina." href="https://t.me/MinisteroSalute">
<span class="fab fa-telegram">
<span style="color:transparent;font-size:0px;">.</span>
</span>
</a>
<a style="padding-left:5px;text-decoration:none;" onclick="window.open(this.href);return false" title="Collegamento alla pagina Linkedin del Ministero della Salute. Apre una nuova pagina." href="https://www.linkedin.com/company/MinisteroSalute">
<span class="fab fa-linkedin">
<span style="color:transparent;font-size:0px;">.</span>
</span>
</a>
<br/>
</span>
</div>
</div>
</div>
<div class="row">
<ul class="col-xs-12 footer__links clearfix">
<li>
<a title="Mappa" href="http://www.salute.gov.it/portale/nuovocoronavirus/dettaglioContenutiNuovoCoronavirus.jsp?lingua=italiano&amp;id=5343&amp;area=nuovoCoronavirus&amp;menu=vuoto">Mappa</a>
</li>
<li>
<a title="Link" href="http://www.salute.gov.it/portale/nuovocoronavirus/dettaglioContenutiNuovoCoronavirus.jsp?lingua=italiano&amp;id=5344&amp;area=nuovoCoronavirus&amp;menu=vuoto">Link</a>
</li>
<li>
<a title="Credits" href="http://www.salute.gov.it/portale/nuovocoronavirus/dettaglioContenutiNuovoCoronavirus.jsp?lingua=italiano&amp;id=5345&amp;area=nuovoCoronavirus&amp;menu=vuoto">Credits</a>
</li>
<li>
<a title="Note legali" href="http://www.salute.gov.it/portale/nuovocoronavirus/dettaglioContenutiNuovoCoronavirus.jsp?lingua=italiano&amp;id=5185&amp;area=nuovoCoronavirus&amp;menu=vuoto">Note legali</a>
</li>
<li>
<a title="Privacy" href="http://www.salute.gov.it/portale/nuovocoronavirus/dettaglioContenutiNuovoCoronavirus.jsp?lingua=italiano&amp;id=5186&amp;area=nuovoCoronavirus&amp;menu=vuoto">Privacy</a>
</li>
<li>
<a title="Accessibilit&agrave;" href="http://www.salute.gov.it/portale/nuovocoronavirus/dettaglioContenutiNuovoCoronavirus.jsp?lingua=italiano&amp;id=5229&amp;area=nuovoCoronavirus&amp;menu=vuoto">Accessibilit&agrave;</a>
</li>
</ul>
</div>
</div>
</footer>
<a class="scrollto_top sr-only" title="torna all'inizio del contenuto" href="#page_top">
<span style="color:#036;">.</span>
</a>
<p role="alert" class="cookie-message sr-only">Il portale utilizza cookie tecnici, analytics e di terze parti per il corretto funzionamento delle pagine web e per fornire le funzionalit&agrave; di condivisione sui social network e la visualizzazione di media. Per avere maggiori informazioni su tutti i cookie utilizzati, su come disabilitarli o negare il consenso all'utilizzo consulta la policy sulla Privacy. Proseguendo nella navigazione presti il consenso all'uso di tutti i cookie.</p><!-- JAVASCRIPT -->
<script src="../scripts/combined-ca1b583c71.js" type="text/javascript"></script>
<script src="../js/jquery.flexslider.js" type="text/javascript"></script>
<script src="../scripts/masonry.pkgd.min.js" type="text/javascript"></script>
<script src="../scripts/imagesloaded.pkgd.min.js" type="text/javascript"></script>


<!-- BEGIN SLIDER -->
<script type="text/javascript">
	l = location.href;
	pagina = l.substr(l.lastIndexOf("/")+1).split(/[?#]/)[0];
	if (pagina == 'homeNuovoCoronavirus.jsp'){
		$(window).load(function() {
			$('.flexslider').flexslider({
				animation: "slide",
				animationLoop: false,
				slideshow: false,
				itemWidth: 230,
				itemMargin: 30,
				controlNav: false,
				directionNav: true,
				prevText: "Precedente",
				nextText: "Successivo",
				move: 1
			});
		});
	} 
</script> 
<!-- END SLIDER -->

<!-- BEGIN SLIDER -->
<script type="text/javascript">
	l = location.href;
	pagina = l.substr(l.lastIndexOf("/")+1).split(/[?#]/)[0];
	if (pagina == 'homeNuovoCoronavirus.html'){
		$(window).load(function() {
			$('.flexslider').flexslider({
				animation: "slide",
				animationLoop: false,
				slideshow: false,
				itemWidth: 230,
				itemMargin: 30,
				controlNav: false,
				directionNav: true,
				prevText: "Precedente",
				nextText: "Successivo",
				move: 1
			});
		});
	} 
</script> 
<!-- END SLIDER -->

<!-- BEGIN SLIDER -->
<script type="text/javascript">
	l = location.href;
	pagina = l.substr(l.lastIndexOf("/")+1).split(/[?#]/)[0];
	if (pagina == 'nuovocoronavirus'){
		$(window).load(function() {
			$('.flexslider').flexslider({
				animation: "slide",
				animationLoop: false,
				slideshow: false,
				itemWidth: 230,
				itemMargin: 30,
				controlNav: false,
				directionNav: true,
				prevText: "Precedente",
				nextText: "Successivo",
				move: 1
			});
		});
	} 
</script> 
<!-- END SLIDER -->


<!-- BEGIN SLIDER -->
<script type="text/javascript">
	l = location.href;
	pagina = l.substr(l.lastIndexOf("/")+1).split(/[?#]/)[0];
	if (pagina == 'homeMobileNuovoCoronavirus.jsp'){
		$(window).load(function() {
			$('.flexslider').flexslider({
				animation: "slide",
				animationLoop: false,
				slideshow: false,
				itemWidth: 230,
				itemMargin: 30,
				controlNav: false,
				directionNav: true,
				prevText: "Precedente",
				nextText: "Successivo",
				move: 1
			});
		});
	} 
</script> 
<!-- END SLIDER -->




<script type="text/javascript">
//Initialize Masonry inside Bootstrap 3 Tab component 

(function( $ ) {

	var \$container = $('.masonry-container');
	\$container.imagesLoaded( function () {
		\$container.masonry({
			columnWidth: '.item',
			itemSelector: '.item'
		});
	});
	
})(jQuery);
</script>


<!-- TEST COOKIE POLICY -->
<script src="../js/js.cookie.js" type="text/javascript"></script>
<!-- TEST COOKIE POLICY BEGIN -->
<script type="text/javascript">
<!-- //
	var privacy_displayed = false;

	var scrollPrivacyHandler = function() {
		if (privacy_displayed) {
			setPrivacy();
		}
	};

	function setPrivacy () {
		$.cookie("pr_cy", 1, { expires: 365, path: '/', domain: '.salute.gov.it' });
		$('#cookiepolicy').remove();
		$(window).off("scroll", scrollPrivacyHandler);
	}

	function findParentId (el, var_id) {
		if (el.id == var_id) {
			return el;
		}

		while (el.parentNode) {
			el = el.parentNode;
			if (el.id == var_id) {
				return el;
			}
		}
		return null;
	}
	if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
		console.log('Browser mobile');
		$(document).on('ready', function() {
			if ($.cookie("pr_cy") != 1) {
				$('<div id="cookiepolicy" style="background-color:#EE8704;font-size:1.6rem;color:#000000;position:fixed;bottom:0;top:auto;width:100%;z-index:10000"><div style="width:auto;height:auto;margin-left:auto;margin-right: auto;padding-left: 10px;"><div style="width: 100%;float: left;padding-right: 24px;">Il portale utilizza cookie tecnici, analytics e di terze parti. Per avere maggiori informazioni su tutti i cookie utilizzati, su come disabilitarli o negare il consenso all&#39 utilizzo consulta la policy sulla <a href="http://www.salute.gov.it/portale/p5_0.jsp?id=51">Privacy</a><br />Proseguendo nella navigazione presti il consenso all&#39;uso di tutti i cookie.<br /><br /><a href="javascript:void(0);" onclick="setPrivacy();" class="button-large3"><b>Ho capito</b></a></div></div></div></div>').appendTo("body");
			}
		});
	}
// -->
</script>
<!-- TEST COOKIE POLICY END -->

<!-- inizio codice analytcs -->
<script type="text/javascript">
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-38402058-42', 'auto');
  ga('set', 'anonymizeIp', true);ga('send', 'pageview');

</script>
<!-- fine codice analytcs --></body>
</html>

_END;
    }
?>