<?php
    require('libreriapagine.php');
    
    
    partesuperiore('Area riservata ai laboratori analisi');
    body('Area riservata ai laboratori analisi per la generazione di codici positivi');
    navbar();
    corpo();
    echo <<<_END
            <h3 style="font-size:30px;margin:0;" class="blu-italia-base-color">
					Area Riservata ai laboratori analisi
				</h3>
        <p>
        In quest' area è possibile generare i codici usa e getta per i cittadini positivi. Per generare un codice, vai nell'area esito esame.
        </p>
_END;
    endcorpo();
?>