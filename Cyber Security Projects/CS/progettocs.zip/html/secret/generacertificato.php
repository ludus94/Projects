<?php
    require('libreriapagine.php');
    
    
    partesuperiore('Generazione Certificati client');
    body('Generazione dei certificati client');
    navbar();
    corpo();
    echo <<<_END
            <h3 style="font-size:30px;margin:0;" class="blu-italia-base-color">
					Generazione Certificati
				</h3>
        <form autocomplete="off" method="post" name="generaform" action="../secret/genssl.php">
            <input name="stateOrProvinceName" type="text" required="required" placeholder="Provincia"><br/>
            <input name="localityName" type="text" required="required" placeholder="Città"><br/>
            <input name="organizationName" type="text" required="required" placeholder="Nome del laboratorio"><br/>
            <input name="commonName" type="text" required="required" placeholder="Nome dell' operatore"><br/>
            <input type="submit" class="btn-s btn-default-s btn-sm">
        </form>
_END;
    endcorpo();
?>