<?php
include('libreriapagine.php');
partesuperiore('Inserisci Codice Monouso');
    body('Inserisci Codice Monouso');
    navbar();
    corpo();
    echo<<<_END
     <h3 style="font-size:30px;margin:0;" class="blu-italia-base-color">
					Inserisci Codice Monouso
				</h3>
        <form autocomplete="off" method="post" name="generaform" action="../code.php">
            <input name="code" type="text" required="required" placeholder="Codice"><br/>
            <input type="submit" class="btn-s btn-default-s btn-sm">
        </form>
_END;
    endcorpo();
?>